#include "hydra_model.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>

int hydra_engine_load(HydraEngine *engine, const char *model_path) {
    if (!engine || !model_path) return -1;
    memset(engine, 0, sizeof(HydraEngine));

    engine->fd = open(model_path, O_RDONLY);
    if (engine->fd < 0) {
        perror("[Hydra] Fehler beim Oeffnen der Modelldatei");
        return -2;
    }

    struct stat sb;
    if (fstat(engine->fd, &sb) < 0) {
        close(engine->fd);
        return -3;
    }
    engine->mapped_size = (size_t)sb.st_size;

    /* Zero-RAM Streaming: OS laedt Seiten direkt vom Flash, kein Heap verbraucht */
    engine->mapped_weights = (const uint8_t *)mmap(
        NULL, engine->mapped_size, PROT_READ, MAP_SHARED, engine->fd, 0
    );

    if (engine->mapped_weights == MAP_FAILED) {
        perror("[Hydra] mmap fehlgeschlagen");
        close(engine->fd);
        return -4;
    }

    /* Validierung Header */
    memcpy(&engine->header, engine->mapped_weights, sizeof(HydraModelHeader));
    if (engine->header.magic != HYDRA_MAGIC) {
        fprintf(stderr, "[Hydra] Ungueltiges Format! Magic: 0x%08X (Erwartet: 0x%08X)\n", 
                engine->header.magic, HYDRA_MAGIC);
        hydra_engine_unload(engine);
        return -5;
    }

    printf("[Hydra] Modell erfolgreich gemappt! Layers: %u, Dim: %u, Vocab: %u\n",
           engine->header.layers, engine->header.dim, engine->header.vocab_size);
    return 0;
}

void hydra_engine_unload(HydraEngine *engine) {
    if (!engine) return;
    if (engine->mapped_weights && engine->mapped_weights != MAP_FAILED) {
        munmap((void *)engine->mapped_weights, engine->mapped_size);
    }
    if (engine->fd >= 0) {
        close(engine->fd);
    }
    memset(engine, 0, sizeof(HydraEngine));
}

/* Inferenz rein ueber ternäre Additionen/Subtraktionen {-1, 0, +1} */
int hydra_engine_step(HydraEngine *engine, uint16_t token_in, uint16_t *token_out) {
    if (!engine || !token_out) return -1;

    const uint8_t *w_ptr = engine->mapped_weights + engine->header.weights_offset;
    size_t dim = engine->header.dim;
    if (dim > HYDRA_EMBED_DIM) dim = HYDRA_EMBED_DIM;

    /* Layer-Verarbeitung on-the-fly ohne Zwischenpuffer im RAM */
    int32_t accumulator[HYDRA_EMBED_DIM] = {0};

    for (uint32_t l = 0; l < engine->header.layers; ++l) {
        for (size_t i = 0; i < dim; ++i) {
            uint8_t packed = *w_ptr++;
            /* Entpacke zwei 2-Bit Ternary Weights: 00 = 0, 01 = +1, 10 = -1 */
            int8_t w1 = ((packed & 0x03) == 1) ? 1 : (((packed & 0x03) == 2) ? -1 : 0);
            int8_t w2 = (((packed >> 2) & 0x03) == 1) ? 1 : ((((packed >> 2) & 0x03) == 2) ? -1 : 0);

            /* Reine Akkumulation ohne Gleitkommamultiplikation */
            accumulator[i] += w1 * (int32_t)(token_in & 0x7F) + w2 * engine->state_vector[i];
        }
    }

    /* Update O(1) State-Vektor */
    for (size_t i = 0; i < dim; ++i) {
        engine->state_vector[i] = (int8_t)(accumulator[i] % 127);
    }

    /* Simples deterministisches Decoding fuer naechsten Token */
    *token_out = (uint16_t)((abs(accumulator[0]) + token_in + 1) % engine->header.vocab_size);
    return 0;
}

int hydra_verify_axiom(float humanity_factor, float proposed_score, float *safe_score) {
    if (!safe_score) return -1;
    if (humanity_factor <= 0.0f) {
        *safe_score = -1e9f; /* Unendlich schlechter Score bei Ausloeschung */
        return 0; /* Blockiert */
    }
    *safe_score = proposed_score * humanity_factor;
    return 1; /* Bestaetigt */
}
