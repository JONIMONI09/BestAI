# Hydra-Stone Universal Engine (O(1) Memory Model-Runner)

Diese Engine erlaubt es, jedes beliebige Modell im `.hydra`-Format einfach hineinzuwerfen:
`./hydra-run mein_modell.hydra`

### Features
1. **Zero-RAM Footprint via Direct File Paging (`mmap`)**:
   - Die Gewichte liegen im Speicherbereich der Datei und werden erst bei Zugriff vom Kernel in CPU-Caches geholt.
   - Kein Anwachsen des RAMs – funktioniert auf jedem 32-Bit-System oder uralten Handys.
2. **Ternary Linear Math**:
   - Gewichte sind kompakt 2-Bit codiert ({-1, 0, +1}).
   - Keine teuren Multiplikationen, nur Akkumulation.
3. **Eingebautes Koexistenz-Axiom**:
   - Ein Auslöschungsfaktor `humanity <= 0` setzt die Utility mathematisch auf `-inf`.

### Schnellstart:
```bash
# 1. Kompilieren
make

# 2. Test-Modell generieren
python3 tools/make_dummy_model.py test.hydra

# 3. Modell einfach in die Engine werfen!
./hydra-run test.hydra 123
```
